"""
core/skill_telemetry.py — v8.4 Skill Execution & Telemetry Router
=================================================================
Answers the routing questions for a registry with many skills:
  - Which skills never get picked even when relevant?   (IGNORED)
  - Which fail mid-execution?                            (success < 70%)
  - Which are too slow / stuck retrying?                 (latency > 15s)

Storage: workspace/skill_metrics.json
Surfaced via: /teach audit   (chat)  +  awareness_block() injected into the
chat system prompt so the model actually KNOWS its skills (the #1 cure for
ignored skills).
"""
from __future__ import annotations

import functools
import json
import logging
import os
import re
import tempfile
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("skill_telemetry")


def _project_root() -> Path:
    """Project root. Order: BUDDY_ROOT, then the nearest folder (here or up to 3 levels up) that holds one of
    the root-only files below, then a folder containing workspace/. Never just "the nearest workspace/":
    stray core/workspace folders are created by older code and used to fool this check."""
    env = os.environ.get("BUDDY_ROOT")
    if env:
        return Path(env).resolve()
    here = Path(__file__).resolve().parent
    candidates = (here, *list(here.parents)[:3])
    markers = ("soul.md", "capabilities.md", "run_buddy.py", "api.py", ".env", "dashboard.html")
    for p in candidates:
        try:
            names = {x.name.lower() for x in p.iterdir()}
        except OSError:
            continue
        if any(m in names for m in markers):
            return p
    for p in candidates:
        if (p / "workspace").is_dir():
            return p
    return here


METRICS_PATH = _project_root() / "workspace" / "skill_metrics.json"


def _synchronized(fn):
    @functools.wraps(fn)
    def wrapper(self, *a, **kw):
        with self._lock:
            return fn(self, *a, **kw)
    return wrapper

GOOD_RATE, BAD_RATE = 0.90, 0.70          # success-rate bands
GOOD_MS, BAD_MS = 3000, 15000             # latency bands (blueprint: <3s, >15s)


def _clean_base(name: str) -> str:
    """'Blender-mcp_repo_800611' -> 'blender-mcp'"""
    base = re.sub(r"_repo_[0-9a-f]{4,}$", "", name, flags=re.IGNORECASE)
    base = re.sub(r"_\d+$", "", base)
    return base.replace("_", " ").strip().lower()


class SkillTelemetry:
    def __init__(self, path: Path = METRICS_PATH):
        self.path = path
        self._lock = threading.RLock()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._data: Dict[str, Dict[str, Any]] = self._load()

    # ---------------- storage ----------------

    def _load(self) -> Dict[str, Dict[str, Any]]:
        if not self.path.exists():
            return {}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            # keep the unreadable file instead of silently overwriting it with an empty one
            try:
                os.replace(self.path, self.path.with_suffix(f".corrupt-{int(time.time())}"))
            except OSError:
                pass
            return {}

    def _save(self) -> None:
        try:
            fd, tmp = tempfile.mkstemp(dir=str(self.path.parent), suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)  # atomic: a crash can never leave a half-written file
        except OSError as e:
            logger.warning(f"Cannot save skill metrics: {e}")

    def _entry(self, name: str) -> Dict[str, Any]:
        return self._data.setdefault(name, {
            "calls": 0, "successes": 0, "failures": 0,
            "total_ms": 0, "max_ms": 0, "last_used": "",
            "last_error": "", "routing_hits": 0,
        })

    # ---------------- recording ----------------

    @_synchronized
    def record_execution(self, skill: str, ok: bool, latency_ms: float,
                         error: str = "") -> None:
        e = self._entry(skill)
        e["calls"] += 1
        e["successes" if ok else "failures"] += 1
        e["total_ms"] += int(latency_ms)
        e["max_ms"] = max(e["max_ms"], int(latency_ms))
        e["last_used"] = datetime.now().isoformat(timespec="seconds")
        if not ok and error:
            e["last_error"] = str(error)[:300]
        self._save()

    @_synchronized
    def record_routing_hit(self, skill: str) -> None:
        self._entry(skill)["routing_hits"] += 1
        self._save()

    # ---------------- analysis ----------------

    @staticmethod
    def _band(e: Dict[str, Any], on_disk: bool) -> Dict[str, str]:
        """Returns {status, fix} for one skill per blueprint thresholds."""
        if not on_disk:
            return {"status": "GHOST", "fix": "registered but missing on disk — re-clone or deregister"}
        calls = e.get("calls", 0)
        if calls == 0:
            hits = e.get("routing_hits", 0)
            if hits == 0:
                return {"status": "IGNORED",
                        "fix": "0 calls + 0 routing hits — sharpen the skill description / add explicit triggers so the router knows when to pick it"}
            return {"status": "PICKED-NOT-RUN",
                    "fix": "router selects it but nothing executes — wire its entry point into mission tasks"}
        rate = e["successes"] / calls
        avg = e["total_ms"] / calls
        if rate < BAD_RATE:
            return {"status": "FAILING",
                    "fix": f"success {rate:.0%} — missing dependencies or bad generated args (last error: {e.get('last_error', '')[:80]})"}
        if avg > BAD_MS:
            return {"status": "SLOW",
                    "fix": f"avg {avg/1000:.1f}s — stuck in retry loops or heavy processing; raise timeout or trim work"}
        if rate < GOOD_RATE or avg > GOOD_MS:
            return {"status": "WATCH", "fix": "within tolerance — keep observing"}
        return {"status": "GOOD", "fix": ""}

    def audit(self, registry=None) -> Dict[str, Any]:
        """Full efficiency breakdown, blueprint-style."""
        rows = []
        names = registry.list_skills() if registry else list(self._data)
        for name in names:
            e = self._entry(name)
            on_disk = True
            if registry:
                sk = registry.get(name)
                on_disk = bool(sk and Path(str(getattr(sk, "path", ""))).exists())
            band = self._band(e, on_disk)
            calls = e.get("calls", 0)
            rate = (e["successes"] / calls) if calls else 0.0
            avg = (e["total_ms"] / calls) if calls else 0.0
            rows.append({
                "skill": name, "calls": calls,
                "success": f"{rate:.0%}" if calls else "-",
                "avg_s": f"{avg/1000:.2f}" if calls else "-",
                "max_s": f"{e.get('max_ms', 0)/1000:.1f}" if calls else "-",
                "picked": e.get("routing_hits", 0),
                "status": band["status"], "fix": band["fix"],
            })
        order = {"FAILING": 0, "SLOW": 1, "GHOST": 2, "IGNORED": 3,
                 "PICKED-NOT-RUN": 4, "WATCH": 5, "GOOD": 6}
        rows.sort(key=lambda r: (order.get(r["status"], 9), -r["calls"]))
        return {
            "rows": rows,
            "total": len(rows),
            "healthy": sum(1 for r in rows if r["status"] == "GOOD"),
            "problems": sum(1 for r in rows if r["status"] in
                            ("FAILING", "SLOW", "GHOST", "IGNORED",
                             "PICKED-NOT-RUN")),
        }

    def audit_lines(self, registry=None) -> List[str]:
        rep = self.audit(registry)
        lines = [f"[Audit] {rep['total']} skills · {rep['healthy']} GOOD · "
                 f"{rep['problems']} need attention", ""]
        for r in rep["rows"]:
            icon = {"GOOD": "✅", "WATCH": "👁", "IGNORED": "💤",
                    "PICKED-NOT-RUN": "🔌", "FAILING": "❌", "SLOW": "🐢",
                    "GHOST": "👻"}.get(r["status"], "·")
            line = (f"{icon} {r['skill'][:34]:34s} calls={r['calls']:<4} "
                    f"success={r['success']:<5} avg={r['avg_s']}s "
                    f"picked={r['picked']}")
            lines.append(line)
            if r["fix"] and r["status"] != "GOOD":
                lines.append(f"   ↳ fix: {r['fix']}")
        return lines

    # ---------------- prompt awareness (cure for IGNORED) ----------------

    @staticmethod
    def _skill_trigger(registry, name: str, limit: int = 90) -> str:
        """'WHEN TO USE:' line from the skill's SKILL.md manifest ('' if none)."""
        try:
            # SkillsRegistry keeps its skills in `.skills` (older code used `._skills`)
            skills = getattr(registry, 'skills', None) or getattr(registry, '_skills', None) or {}
            skill = skills.get(name)
            p = getattr(skill, 'path', None)
            if not p:
                return ""
            sm = Path(p) / 'SKILL.md'
            if not sm.exists():
                return ""
            for line in sm.read_text(errors='ignore').splitlines():
                if line.strip().upper().startswith('WHEN TO USE:'):
                    txt = line.split(':', 1)[1].strip()
                    return (txt[:limit] + '…') if len(txt) > limit else txt
        except Exception:
            pass
        return ""

    def awareness_block(self, registry, max_skills: int = 15,
                        max_chars: int = 2400) -> str:
        """Dynamic skill manifest for the system prompt: models pick tools
        from descriptions, so an explicit trigger list beats silence.

        v8.5: budget raised 900 -> 2400 chars — 15 skills x ~135-char
        lines (~2000 total) did not fit at 900; tail skills were being
        silently cut from the prompt.
        """
        if not registry:
            return ""
        names = registry.list_skills()
        if not names:
            return ""
        # surface recently-successful + never-called skills first: the ones
        # the router most needs to reconsider
        scored = sorted(
            names,
            key=lambda n: (self._entry(n).get("calls", 0),
                           self._entry(n).get("routing_hits", 0)))
        chosen = scored[:max_skills]
        lines = ["INSTALLED SKILLS (local repos in workspace/skills — when a "
                 "task matches one of these domains, say so explicitly and "
                 "use/analyze that skill, e.g. 'analyze skill <name>'):"]
        total = len(lines[0])
        for n in chosen:
            line = f"- {_clean_base(n)} (skill '{n}')"
            trig = self._skill_trigger(registry, n)
            if trig:
                line += f": {trig}"
            if total + len(line) + 1 > max_chars:
                break
            lines.append(line)
            total += len(line) + 1
        more = len(names) - len(lines) + 1
        if more > 0:
            lines.append(f"- ...and {more} more (say '/skills' concept: full list)")
        return "\n".join(lines)


# Module-level singleton — Skill.run_file and find_referenced call this
# directly without any wiring changes at call sites.
telemetry = SkillTelemetry()
