"""
Buddy OS v8 — Skill Forge
=========================
"Any skill in this world": when Buddy needs a capability it doesn't have,
it FORGES one — writes a Python skill module, syntax-checks it, smoke-tests
it in a subprocess, and registers it permanently in the SkillRegistry.

Forged skill contract (generated code must follow this):
    META = {
        'name': str,
        'version': '1.0.0',
        'description': str,
        'capabilities': [str, ...],
    }
    def run(task: dict) -> dict:
        # task: {'action': str, ...params}
        # must return {'status': 'OK'} or {'status': 'ERROR', 'message': str}
    def selftest() -> dict:
        # offline self-check, no network, no user input, < 30s
        # returns {'status': 'OK'} or {'status': 'ERROR', 'message': str}

Skills are plain files in workspace/skills/forged/<name>/ — inspectable,
editable by the user, and re-usable by every future mission.
"""

import ast
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

def _project_root() -> Path:
    """Project root. Order: BUDDY_ROOT, then the nearest folder (here or up to 3 levels up) that holds one of
    the root-only files below, then a folder containing workspace/. Never just "the nearest workspace/":
    stray core/workspace folders are created by older code and used to fool this check."""
    env = os.environ.get("BUDDY_ROOT")
    if env:
        return Path(env).resolve()
    here = Path(__file__).resolve().parent
    candidates = (here, *list(here.parents)[:3])
    markers = ("soul.md", "capabilities.md", "run_buddy.py", "api.py", ".env", "dashboard.html")
    for p in candidates:
        try:
            names = {x.name.lower() for x in p.iterdir()}
        except OSError:
            continue
        if any(m in names for m in markers):
            return p
    for p in candidates:
        if (p / "workspace").is_dir():
            return p
    return here


_SECRET_HINTS = ("KEY", "TOKEN", "SECRET", "PASSWORD", "PASSWD", "CREDENTIAL", "AUTH")


def _scrubbed_env(passthrough=()) -> dict:
    """Environment for untrusted/third-party code: API keys, tokens and passwords are NOT inherited."""
    keep = set(passthrough)
    return {k: v for k, v in os.environ.items()
            if k in keep or not any(h in k.upper() for h in _SECRET_HINTS)}

FORGED_DIR = _project_root() / 'workspace' / 'skills' / 'forged'
_SECRET_NAME = re.compile(r'(KEY|TOKEN|SECRET|PASSWORD|PASSWD|CREDENTIAL)', re.I)
_DANGEROUS_CALLS = {'eval', 'exec', '__import__'}
_DANGEROUS_ATTRS = {('os', 'system'), ('os', 'popen'), ('os', 'startfile'), ('shutil', 'rmtree'),
                    ('os', 'remove'), ('os', 'unlink'), ('os', 'rmdir'), ('os', 'removedirs')}


class SkillForge:
    def __init__(self, llm_router, skills_registry, log=None):
        """
        llm_router:      Any object with .chat.completions.create() (OllamaClient compatible)
        skills_registry: SkillRegistry instance
        log:             optional callable(str) for progress lines
        """
        self.router = llm_router
        self.skills = skills_registry
        self.log = log or (lambda msg: print(msg, flush=True))
        FORGED_DIR.mkdir(parents=True, exist_ok=True)
        self.forge_history_path = FORGED_DIR / '_forge_history.json'

    # ------------------------------------------------------------------
    def _safe_name(self, name: str) -> str:
        slug = re.sub(r'[^a-z0-9_]+', '_', (name or 'skill').lower()).strip('_')
        return slug or 'skill'

    # ------------------------------------------------------------------
    @staticmethod
    def _policy_violations(code: str) -> list:
        """Static safety screen for LLM-written code (it will be executed). Not a sandbox, a tripwire."""
        out = []
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return out
        for n in ast.walk(tree):
            if isinstance(n, ast.Call):
                f = n.func
                if isinstance(f, ast.Name) and f.id in _DANGEROUS_CALLS:
                    out.append(f'{f.id}() is not allowed')
                if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name) and (f.value.id, f.attr) in _DANGEROUS_ATTRS:
                    out.append(f'{f.value.id}.{f.attr}() is not allowed')
                if any(k.arg == 'shell' and isinstance(k.value, ast.Constant) and k.value.value is True for k in n.keywords):
                    out.append('subprocess with shell=True is not allowed')
                is_env_get = isinstance(f, ast.Attribute) and (
                    f.attr == 'getenv' or (f.attr == 'get' and isinstance(f.value, ast.Attribute) and f.value.attr == 'environ'))
                if is_env_get and n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str) \
                        and _SECRET_NAME.search(n.args[0].value):
                    out.append(f'reading secret environment variable {n.args[0].value!r} is not allowed')
            elif isinstance(n, ast.Subscript) and isinstance(n.value, ast.Attribute) and n.value.attr == 'environ':
                sl = n.slice
                if isinstance(sl, ast.Constant) and isinstance(sl.value, str) and _SECRET_NAME.search(sl.value):
                    out.append(f'reading secret environment variable {sl.value!r} is not allowed')
        return sorted(set(out))

    # ------------------------------------------------------------------
    def has_capability(self, description: str) -> bool:
        """True if an existing registered skill plausibly covers this."""
        if self.skills.find_referenced(description):
            return True
        matches = self.skills.search_all(description, max_per_skill=1)
        return bool(matches)

    # ------------------------------------------------------------------
    def forge(self, description: str, name: Optional[str] = None,
              smoke_test: bool = True) -> Dict[str, Any]:
        """
        Create a new skill from a natural-language capability description.
        Returns {'status': 'OK'|'ERROR', 'skill': name, 'path': ..., ...}
        """
        t0 = time.time()
        name = self._safe_name(name or description)[:40]
        self.log(f'[SkillForge] Forging skill "{name}" from: {description[:80]}...')

        # 1) Ask the LLM to write the skill
        prompt = f"""Write a complete, self-contained Python skill module.

CAPABILITY: {description}

STRICT REQUIREMENTS:
1. Top-level META dict: keys name='{name}', version, description, capabilities (list of strings).
2. def run(task: dict) -> dict — main entry. Read params from task dict. ALWAYS return
   a dict with 'status': 'OK' or 'ERROR' (+'message' on error, + results on success).
3. def selftest() -> dict — OFFLINE self-check (no network, no user input, < 10 seconds),
   returns same status convention.
4. Standard library only, or guard optional imports inside functions with try/except ImportError
   and return a clear ERROR telling the user what to pip install.
5. No shell injection: never pass user strings to shell=True. No eval/exec of task data.
6. If the skill writes files, write them under the current working directory in a folder
   named 'output/{name}/'.
7. Add `if __name__ == '__main__':` block that calls `selftest()` and prints the result as JSON.
8. Return ONLY the Python source in one ```python code block, no explanations.

Remember: run() and selftest() must both exist and work standalone."""

        try:
            # Handle both HybridRouter and OllamaClient interfaces
            if hasattr(self.router, 'chat') and hasattr(self.router.chat, 'completions'):
                resp = self.router.chat.completions.create(
                    model=None,
                    messages=[{'role': 'user', 'content': prompt}],
                    temperature=0.2,
                    max_tokens=4000,
                )
            elif hasattr(self.router, 'generate'):
                # Fallback for legacy generate() interface
                resp_text = self.router.generate(prompt, system="You are a Python expert writing skill modules.")
                # Wrap in mock response object
                class MockResponse:
                    def __init__(self, content):
                        self.choices = [type('obj', (object,), {'message': type('obj', (object,), {'content': content})()})()]
                resp = MockResponse(resp_text)
            else:
                return {'status': 'ERROR', 'message': 'LLM router has no compatible interface (need chat.completions.create or generate)'}

            raw = resp.choices[0].message.content or ''
            code = self._extract_code(raw)
            if not code:
                return {'status': 'ERROR', 'message': 'Model returned no parseable python block'}

        except Exception as e:
            return {'status': 'ERROR', 'message': f'LLM call failed: {e}'}

        # 2) Static syntax check
        try:
            ast.parse(code)
        except SyntaxError as e:
            fix = self._ask_fix(code, f'SyntaxError: {e}')
            if not fix:
                return {'status': 'ERROR', 'message': f'Forged skill has syntax error: {e}'}
            code = fix

        # 3) Contract check: META + run() + selftest() must exist
        missing = [sym for sym in ('META', 'def run(', 'def selftest(') if sym not in code]
        if missing:
            fix = self._ask_fix(code, f'Missing required symbols: {missing}')
            if not fix:
                return {'status': 'ERROR', 'message': f'Forged skill missing: {missing}'}
            code = fix

        # 3b) Safety screen (this code is about to be executed)
        problems = self._policy_violations(code)
        if problems:
            fix = self._ask_fix(code, 'Safety policy violations, remove them: ' + '; '.join(problems))
            if not fix or self._policy_violations(fix):
                return {'status': 'ERROR', 'message': 'Forged skill rejected by safety policy: ' + '; '.join(problems)}
            code = fix

        # 4) Write to disk (never silently overwrite an earlier version of the same skill)
        skill_dir = FORGED_DIR / name
        skill_dir.mkdir(parents=True, exist_ok=True)
        skill_file = skill_dir / 'main.py'
        if skill_file.exists():
            (skill_dir / 'main.prev.py').write_bytes(skill_file.read_bytes())
        skill_file.write_text(code, encoding='utf-8')

        result = {
            'skill': name, 'path': str(skill_dir),
            'provider': getattr(resp, 'provider', 'unknown'),
            'verified': False,
        }

        # 5) Smoke test in a subprocess (isolated, timeout-bounded)
        if smoke_test:
            ok, detail = self._smoke_test(skill_file)
            result['selftest'] = detail
            if not ok:
                # one repair attempt
                self.log(f'[SkillForge] Selftest failed ({detail[:100]}) — attempting repair...')
                fixed = self._ask_fix(code, f'selftest() failed: {detail}')
                if fixed and not self._policy_violations(fixed):
                    skill_file.write_text(fixed, encoding='utf-8')
                    ok, detail = self._smoke_test(skill_file)
                    result['selftest'] = detail
            result['verified'] = ok

        # 6) Register permanently
        try:
            skill = self.skills.register_local(skill_dir, name=name)
            result['registered_as'] = skill.name
        except Exception as e:
            result['register_error'] = str(e)

        result['status'] = 'OK'
        result['seconds'] = round(time.time() - t0, 1)
        self._log_history(result)
        self.log(
            f'[SkillForge] Skill "{name}" forged in {result["seconds"]}s '
            f'({"verified" if result["verified"] else "UNVERIFIED — review " + str(skill_file)})'
        )
        return result

    # ------------------------------------------------------------------
    def ensure_capability(self, description: str, name: Optional[str] = None) -> Dict[str, Any]:
        """Forge only if nothing existing covers the capability."""
        safe = self._safe_name(name or description)[:40]
        if (FORGED_DIR / safe / 'main.py').exists() and self.skills.get(safe):
            return {'status': 'OK', 'existing': True, 'skill': safe, 'message': 'Already forged earlier'}
        if self.has_capability(description):
            return {'status': 'OK', 'existing': True, 'message': 'Existing skill covers this'}
        return self.forge(description, name=name)

    # ------------------------------------------------------------------
    def _extract_code(self, raw: str) -> str:
        m = re.search(r'```python\s*(.*?)\s*```', raw, re.DOTALL)
        if m:
            return m.group(1)
        if raw.strip().startswith(('"""', "'''", 'import', 'from', 'META', '#')):
            return raw.strip()
        return ''

    def _ask_fix(self, code: str, problem: str) -> str:
        try:
            if hasattr(self.router, 'chat') and hasattr(self.router.chat, 'completions'):
                resp = self.router.chat.completions.create(
                    model=None,
                    messages=[{'role': 'user', 'content':
                        f'Fix this Python skill. Problem: {problem}\n\n'
                        f'Keep the contract (META, run(task), selftest()). '
                        f'Return ONLY the corrected full source in one ```python block.\n\n{code}'}],
                    temperature=0.0, max_tokens=4000,
                )
                return self._extract_code(resp.choices[0].message.content or '')
            elif hasattr(self.router, 'generate'):
                prompt = f'Fix this Python skill. Problem: {problem}\n\nKeep the contract (META, run(task), selftest()). Return ONLY the corrected full source in one ```python block.\n\n{code}'
                resp_text = self.router.generate(prompt, system="You are a Python expert fixing skill modules.")
                return self._extract_code(resp_text)
        except Exception:
            pass
        return ''

    def _smoke_test(self, skill_file: Path, timeout: int = 45):
        try:
            skill_path = str(skill_file.resolve())
            skill_dir = str(skill_file.parent.resolve())
            proc = subprocess.run(
                [sys.executable, skill_path],
                capture_output=True, text=True, timeout=timeout, cwd=skill_dir,
                env=_scrubbed_env(),  # forged code never sees API keys / tokens
            )
            out = (proc.stdout or '') + (proc.stderr or '')
            if proc.returncode == 0 and '"status": "OK"' in out.replace("'", '"'):
                return True, out.strip()[:300]
            return False, (out.strip()[:300] or f'exit code {proc.returncode}')
        except subprocess.TimeoutExpired:
            return False, f'selftest timed out after {timeout}s'
        except Exception as e:
            return False, str(e)[:300]

    def _log_history(self, entry: Dict[str, Any]):
        try:
            hist = []
            if self.forge_history_path.exists():
                hist = json.loads(self.forge_history_path.read_text(encoding='utf-8'))
            hist.append({**entry, 'ts': datetime.now().isoformat(timespec='seconds')})
            self.forge_history_path.write_text(json.dumps(hist[-500:], indent=2), encoding='utf-8')
        except Exception:
            pass


if __name__ == '__main__':
    # Manual test:  python core/skill_forge.py "convert CSV files to JSON"
    desc = sys.argv[1] if len(sys.argv) > 1 else 'convert CSV text to JSON'
    from core.skills_registry import SkillRegistry

    # Use the OllamaClient from run_buddy as router
    import sys as _sys
    _sys.path.insert(0, str(Path(__file__).parent.parent))
    from run_buddy import OllamaClient

    router = OllamaClient()
    forge = SkillForge(router, SkillRegistry())
    print(json.dumps(forge.forge(desc), indent=2, default=str))