import importlib.util
import os
import sys
from pathlib import Path


def _project_root() -> Path:
    """Project root. Order: BUDDY_ROOT, then the nearest folder (here or up to 3 levels up) that holds one of
    the root-only files below, then a folder containing workspace/. Never just "the nearest workspace/":
    stray core/workspace folders are created by older code and used to fool this check."""
    env = os.environ.get("BUDDY_ROOT")
    if env:
        return Path(env).resolve()
    here = Path(__file__).resolve().parent
    candidates = (here, *list(here.parents)[:3])
    markers = ("soul.md", "capabilities.md", "run_buddy.py", "api.py", ".env", "dashboard.html")
    for p in candidates:
        try:
            names = {x.name.lower() for x in p.iterdir()}
        except OSError:
            continue
        if any(m in names for m in markers):
            return p
    for p in candidates:
        if (p / "workspace").is_dir():
            return p
    return here


class SkillLoader:
    def __init__(self, skills_dir="Skills"):
        p = Path(skills_dir)
        self.skills_dir = str((p if p.is_absolute() else _project_root() / p).resolve())
        os.makedirs(self.skills_dir, exist_ok=True)

    def load_all_skills(self):
        """Dynamically loads all python modules present in the Skills/ folder."""
        loaded_skills, failed = [], []
        for filename in sorted(os.listdir(self.skills_dir)):
            if not filename.endswith(".py") or filename.startswith("_"):  # skips __init__.py and private files
                continue
            skill_name = filename[:-3]
            file_path = os.path.join(self.skills_dir, filename)
            mod_name = f"buddy_skill_{skill_name}"
            try:
                spec = importlib.util.spec_from_file_location(mod_name, file_path)
                module = importlib.util.module_from_spec(spec)
                sys.modules[mod_name] = module
                spec.loader.exec_module(module)
                # keep the old bare-name registration, but never shadow a real/installed module
                if skill_name not in sys.modules and importlib.util.find_spec(skill_name) is None:
                    sys.modules[skill_name] = module
                loaded_skills.append(skill_name)
            except Exception as e:
                sys.modules.pop(mod_name, None)  # no half-initialised leftovers
                failed.append((skill_name, f"{type(e).__name__}: {e}"))
        print(f"[Skill Loader] integrated {len(loaded_skills)} local skills"
              + (f", {len(failed)} failed to load" if failed else ""))
        for name, err in failed[:5]:
            print(f"[Skill Loader]   {name}: {err}")
        if len(failed) > 5:
            print(f"[Skill Loader]   ... and {len(failed) - 5} more")
        return loaded_skills
